# Enabling and disabling local crash dumps

This repo contains two reg script files for enabling and disabling local user crash dumps, and a utility for checking that your settings actually works

Download the zipped package from the release.

The content and how to use it, is further described in this [How to article](http://hermit.no/enabledisable-user-dumps/).

More information on user dumps can be found in [this MSDN article](https://msdn.microsoft.com/en-us/library/windows/desktop/bb787181%28v=vs.85%29.aspx)